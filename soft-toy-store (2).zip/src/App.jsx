import React from "react";
import { Routes, Route, Link } from "react-router-dom";

const products = [
  {
    name: "Soft Toy",
    price: "₹799",
    features: ["Glowing heart", "Built-in light", "Super soft & cuddly"],
    image: "/soft-toy.jpg",
  },
  {
    name: "Night Panda Light",
    price: "₹699",
    features: ["7 color LED", "Rechargeable", "Cute & kid-friendly"],
    image: "/panda-light.jpg",
  },
];

const Home = () => (
  <div style={{ padding: "2rem", textAlign: "center" }}>
    <h1 style={{ fontSize: "2rem", fontWeight: "bold" }}>Soft Toy Store</h1>
    <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "2rem", marginTop: "2rem" }}>
      {products.map((product, index) => (
        <div key={index} style={{ border: "1px solid #ccc", padding: "1rem", borderRadius: "12px", maxWidth: "200px" }}>
          <img src={product.image} alt={product.name} style={{ width: "100%" }} />
          <h2>{product.name}</h2>
          <p>{product.price}</p>
          <ul>
            {product.features.map((feature, i) => <li key={i}>{feature}</li>)}
          </ul>
        </div>
      ))}
    </div>
  </div>
);

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
    </Routes>
  );
}

export default App;
